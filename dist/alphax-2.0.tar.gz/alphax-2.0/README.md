# coarse_to_alpha
convert coarse binary masks to smooth alpha mask with single command
